Arduino code por SPEC-Sensors modules
